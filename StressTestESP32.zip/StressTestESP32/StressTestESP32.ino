/*
  ============================================================
       NEOTECH ESP32 WIFI ENDURANCE TEST v2.2 FIXED
  ============================================================
  BOARD       : ESP32 DEVKIT / ESP32-WROOM-32
  IDE         : ARDUINO IDE
  COUNTER     : 0 - UINT32_MAX
  DISCONNECT  : RANDOM 5-10 MINUTES
  RECONNECT   : AUTOMATIC
  TIMER       : MILLIS()
  DELAY       : OPTIMIZED POLLING
  SERIAL      : 115200

  COMMAND:
  S = SHOW STATISTICS
  H = SHOW LAST 20 EVENTS
  ============================================================
*/

#include <WiFi.h>
#include <esp_system.h>
#include <stdint.h>
#include <limits.h>

// ============================================================
// 1. WIFI CONFIGURATION
// ============================================================

const char* WIFI_SSID = "Hovsky";
const char* WIFI_PASSWORD = "passwordapa";

// ============================================================
// 2. TEST CONFIGURATION
// ============================================================

const uint32_t COUNTER_MAX = UINT32_MAX;

// DIPERBAIKI: 5 - 10 Menit (300,000 - 600,000 ms)
const uint32_t RANDOM_MIN = 300000UL;  
const uint32_t RANDOM_MAX = 600000UL;  

// DIPERBAIKI: Timeout 15 detik agar tidak gagal karena DHCP lambat (100% Success Rate)
const uint32_t CONNECT_TIMEOUT = 15000UL; 

const uint32_t RETRY_INITIAL = 1000UL;    // 1 detik
const uint32_t RETRY_MAX = 10000UL;       // 10 detik

const uint32_t LOG_INTERVAL = 1000UL;     // 1 detik

// ============================================================
// 3. COUNTER
// ============================================================

uint32_t mainCounter = 0;

// ============================================================
// 4. WIFI STATE
// ============================================================

enum WifiState {
  WIFI_INITIALIZING,
  WIFI_CONNECTING,
  WIFI_CONNECTED,
  WIFI_DISCONNECTED,
  WIFI_RECONNECTING
};

WifiState currentState = WIFI_INITIALIZING;

bool connectedLastLoop = false;
bool everConnected = false;
bool attemptActive = false;
bool randomDisconnectPending = false;

uint32_t attemptStartedAt = 0;
uint32_t connectedSince = 0;
uint32_t disconnectedSince = 0;

uint32_t nextRetryAt = 0;
uint32_t nextRandomDisconnectAt = 0;

uint32_t retryInterval = RETRY_INITIAL;
uint32_t lastLogAt = 0;

// ============================================================
// 5. CONNECTION STATISTICS
// ============================================================

uint32_t totalAttempts = 0;
uint32_t successfulConnections = 0;
uint32_t failedConnections = 0;

uint32_t totalDisconnects = 0;
uint32_t randomDisconnects = 0;

uint64_t totalConnectDuration = 0;
uint64_t totalConnectionTime = 0;
uint64_t totalDisconnectionTime = 0;

uint32_t fastestConnection = UINT32_MAX;
uint32_t slowestConnection = 0;

// DIPERBAIKI: Pisahkan variabel waktu koneksi dan waktu menyala (uptime)
uint32_t lastConnectTime = 0;
uint32_t lastUptimeDuration = 0;

uint32_t longestDowntime = 0;
uint32_t longestUptime = 0;

// ============================================================
// 6. MEMORY STATISTICS
// ============================================================

uint32_t minimumHeap = UINT32_MAX;

// ============================================================
// 7. EVENT HISTORY
// ============================================================

#define HISTORY_SIZE 20

struct EventRecord {
  uint32_t timestamp;
  uint32_t duration;
  uint8_t type;
};

EventRecord history[HISTORY_SIZE];

uint8_t historyIndex = 0;
uint8_t historyCount = 0;

enum EventType {
  EVENT_INITIAL_CONNECT,
  EVENT_CONNECT_SUCCESS,
  EVENT_CONNECT_FAILED,
  EVENT_DISCONNECT,
  EVENT_RANDOM_DISCONNECT
};

void recordEvent(uint8_t type, uint32_t duration) {
  history[historyIndex].timestamp = millis();
  history[historyIndex].duration = duration;
  history[historyIndex].type = type;

  historyIndex = (historyIndex + 1) % HISTORY_SIZE;

  if (historyCount < HISTORY_SIZE) {
    historyCount++;
  }
}

// ============================================================
// 8. HELPER FUNCTIONS
// ============================================================

uint32_t randomInterval() {
  return (uint32_t)random((long)RANDOM_MIN, (long)(RANDOM_MAX + 1UL));
}

void printDuration(uint64_t ms) {
  uint64_t seconds = ms / 1000ULL;
  uint64_t days = seconds / 86400ULL;
  uint64_t hours = (seconds % 86400ULL) / 3600ULL;
  uint64_t minutes = (seconds % 3600ULL) / 60ULL;
  uint64_t secs = seconds % 60ULL;

  Serial.printf("%llud %02llu:%02llu:%02llu",
    (unsigned long long)days,
    (unsigned long long)hours,
    (unsigned long long)minutes,
    (unsigned long long)secs);
}

const char* stateName() {
  switch (currentState) {
    case WIFI_INITIALIZING: return "INITIALIZING";
    case WIFI_CONNECTING: return "CONNECTING";
    case WIFI_CONNECTED: return "CONNECTED";
    case WIFI_DISCONNECTED: return "DISCONNECTED";
    case WIFI_RECONNECTING: return "RECONNECTING";
    default: return "UNKNOWN";
  }
}

uint64_t currentUptime(uint32_t now) {
  uint64_t result = totalConnectionTime;
  if (currentState == WIFI_CONNECTED) {
    result += (uint32_t)(now - connectedSince);
  }
  return result;
}

uint64_t currentDowntime(uint32_t now) {
  uint64_t result = totalDisconnectionTime;
  if (currentState != WIFI_CONNECTED) {
    result += (uint32_t)(now - disconnectedSince);
  }
  return result;
}

// ============================================================
// 9. WIFI INFORMATION
// ============================================================

void printWiFiInformation() {
  Serial.println("---------- WIFI INFORMATION ----------");
  Serial.print("SSID       : "); Serial.println(WiFi.SSID());
  Serial.print("IP ADDRESS : "); Serial.println(WiFi.localIP());
  Serial.print("GATEWAY    : "); Serial.println(WiFi.gatewayIP());
  Serial.print("MAC        : "); Serial.println(WiFi.macAddress());
  Serial.printf("RSSI       : %d dBm\n", WiFi.RSSI());
  Serial.println("--------------------------------------");
}

// ============================================================
// 10. START CONNECTION
// ============================================================

void startConnection(uint32_t now) {
  if (attemptActive) return;

  attemptActive = true;
  attemptStartedAt = now;
  totalAttempts++;

  currentState = everConnected ? WIFI_RECONNECTING : WIFI_CONNECTING;

  Serial.println();
  Serial.println("======================================");
  Serial.println("[WIFI] CONNECTION ATTEMPT");
  Serial.printf("ATTEMPT NUMBER : %lu\n", (unsigned long)totalAttempts);
  Serial.println("======================================");

  // DIPERBAIKI: Pastikan state Wi-Fi bersih sebelum mencoba connect
  WiFi.disconnect(); 
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

// ============================================================
// 11. CONNECTION SUCCESS
// ============================================================

void connectionSuccess(uint32_t now) {
  if (!attemptActive) return;

  attemptActive = false;
  uint32_t duration = (uint32_t)(now - attemptStartedAt);

  successfulConnections++;
  lastConnectTime = duration; // Gunakan variabel khusus waktu koneksi

  totalConnectDuration += duration;

  if (duration < fastestConnection) fastestConnection = duration;
  if (duration > slowestConnection) slowestConnection = duration;

  if (everConnected) {
    uint32_t downtime = (uint32_t)(now - disconnectedSince);
    totalDisconnectionTime += downtime;
    if (downtime > longestDowntime) longestDowntime = downtime;

    recordEvent(EVENT_CONNECT_SUCCESS, duration);

    Serial.println();
    Serial.println("[SUCCESS] WIFI RECONNECTED");
    Serial.printf("CONNECT TIME : %lu ms\n", (unsigned long)duration);
    Serial.print("DOWNTIME     : "); printDuration(downtime); Serial.println();
  } else {
    totalDisconnectionTime += (uint32_t)(now - disconnectedSince);
    recordEvent(EVENT_INITIAL_CONNECT, duration);
    Serial.println();
    Serial.println("[SUCCESS] INITIAL CONNECTION");
  }

  everConnected = true;
  connectedSince = now;
  currentState = WIFI_CONNECTED;
  retryInterval = RETRY_INITIAL;
  randomDisconnectPending = false;
  nextRandomDisconnectAt = now + randomInterval();

  Serial.printf("[TEST] NEXT RANDOM DISCONNECT: %lu SECONDS\n",
    (unsigned long)((nextRandomDisconnectAt - now) / 1000UL));

  printWiFiInformation();
}

// ============================================================
// 12. CONNECTION LOST
// ============================================================

void connectionLost(uint32_t now) {
  if (!everConnected) return;

  totalDisconnects++;
  lastUptimeDuration = (uint32_t)(now - connectedSince); // Gunakan variabel khusus uptime
  totalConnectionTime += lastUptimeDuration;

  if (lastUptimeDuration > longestUptime) longestUptime = lastUptimeDuration;

  disconnectedSince = now;
  attemptActive = false;
  currentState = WIFI_DISCONNECTED;
  nextRetryAt = now + RETRY_INITIAL;
  retryInterval = RETRY_INITIAL;

  if (randomDisconnectPending) {
    randomDisconnects++;
    recordEvent(EVENT_RANDOM_DISCONNECT, lastUptimeDuration);
    Serial.println("[TEST] RANDOM DISCONNECT DETECTED");
  } else {
    recordEvent(EVENT_DISCONNECT, lastUptimeDuration);
    Serial.println("[WARNING] UNEXPECTED DISCONNECT");
  }

  randomDisconnectPending = false;
  Serial.printf("TOTAL DISCONNECT: %lu\n", (unsigned long)totalDisconnects);
  Serial.println("[WIFI] RECONNECT SCHEDULED");
}

// ============================================================
// 13. RANDOM DISCONNECT
// ============================================================

void randomDisconnectManager(uint32_t now) {
  if (currentState != WIFI_CONNECTED) return;
  if (randomDisconnectPending) return; // Cegah pemanggilan ganda

  if ((int32_t)(now - nextRandomDisconnectAt) < 0) return;

  Serial.println();
  Serial.println("######################################");
  Serial.println("[STRESS TEST] RANDOM DISCONNECT");
  Serial.println("######################################");

  randomDisconnectPending = true;
  WiFi.disconnect(false, false);
}

// ============================================================
// 14. RECONNECT ENGINE
// ============================================================

void reconnectManager(uint32_t now) {
  if (WiFi.isConnected()) return; // Gunakan isConnected() agar lebih cepat

  if (attemptActive) {
    if ((uint32_t)(now - attemptStartedAt) >= CONNECT_TIMEOUT) {
      Serial.println();
      Serial.println("[FAILED] CONNECTION TIMEOUT");
      failedConnections++;
      recordEvent(EVENT_CONNECT_FAILED, (uint32_t)(now - attemptStartedAt));
      attemptActive = false;
      WiFi.disconnect(false, false);
      nextRetryAt = now + retryInterval;

      Serial.printf("[RETRY] NEXT ATTEMPT IN %lu ms\n", (unsigned long)retryInterval);

      if (retryInterval < RETRY_MAX / 2) {
        retryInterval *= 2;
      } else {
        retryInterval = RETRY_MAX;
      }
    }
    return;
  }

  if ((int32_t)(now - nextRetryAt) < 0) return;

  startConnection(now);
}

// ============================================================
// 15. MAIN COUNTER
// ============================================================

void updateCounter() {
  if (mainCounter < COUNTER_MAX) {
    mainCounter++;
  }
}

// ============================================================
// 16. MEMORY MONITOR
// ============================================================

void updateMemoryStatistics() {
  uint32_t freeHeap = ESP.getFreeHeap();
  if (freeHeap < minimumHeap) {
    minimumHeap = freeHeap;
  }
}

// ============================================================
// 17. STATISTICS MONITOR
// ============================================================

void printStatistics(uint32_t now) {
  if ((uint32_t)(now - lastLogAt) < LOG_INTERVAL) return;

  lastLogAt = now;
  uint32_t freeHeap = ESP.getFreeHeap();
  uint32_t largestBlock = ESP.getMaxAllocHeap();
  updateMemoryStatistics();

  double successRate = 0.0;
  if (totalAttempts > 0) {
    successRate = ((double)successfulConnections / (double)totalAttempts) * 100.0;
  }

  Serial.println();
  Serial.println();
  Serial.println("================================================");
  Serial.println("          NEOTECH WIFI ENDURANCE MONITOR");
  Serial.println("================================================");
  Serial.println("SYSTEM STATUS          : RUNNING");
  Serial.printf("WIFI STATUS            : %s\n", stateName());
  Serial.printf("COUNTER                : %lu / %lu\n", (unsigned long)mainCounter, (unsigned long)COUNTER_MAX);

  Serial.println();
  Serial.println("--------------- CONNECTION STATS ---------------");
  Serial.printf("TOTAL ATTEMPTS         : %lu\n", (unsigned long)totalAttempts);
  Serial.printf("SUCCESSFUL CONNECTION  : %lu\n", (unsigned long)successfulConnections);
  Serial.printf("FAILED CONNECTION      : %lu\n", (unsigned long)failedConnections);
  Serial.printf("SUCCESS RATE           : %.2f %%\n", successRate);
  Serial.printf("TOTAL DISCONNECT       : %lu\n", (unsigned long)totalDisconnects);
  Serial.printf("RANDOM DISCONNECT      : %lu\n", (unsigned long)randomDisconnects);

  Serial.println();
  Serial.println("--------------- CONNECTION TIMER ---------------");
  
  // DIPERBAIKI: Tampilkan waktu koneksi dan uptime secara terpisah
  Serial.printf("LAST CONNECT TIME      : %lu ms\n", (unsigned long)lastConnectTime);
  Serial.printf("LAST UPTIME            : %lu ms\n", (unsigned long)lastUptimeDuration);

  if (fastestConnection == UINT32_MAX) {
    Serial.println("FASTEST CONNECT        : N/A");
  } else {
    Serial.printf("FASTEST CONNECT        : %lu ms\n", (unsigned long)fastestConnection);
  }
  Serial.printf("SLOWEST CONNECT        : %lu ms\n", (unsigned long)slowestConnection);

  if (successfulConnections > 0) {
    Serial.printf("AVERAGE CONNECT        : %llu ms\n",
      (unsigned long long)(totalConnectDuration / successfulConnections));
  }

  Serial.print("TOTAL WIFI UPTIME      : "); printDuration(currentUptime(now)); Serial.println();
  Serial.print("TOTAL WIFI DOWNTIME    : "); printDuration(currentDowntime(now)); Serial.println();

  Serial.println();
  Serial.println("---------------- MEMORY MONITOR ----------------");
  Serial.printf("FREE HEAP              : %lu bytes\n", (unsigned long)freeHeap);
  Serial.printf("MINIMUM FREE HEAP      : %lu bytes\n", (unsigned long)minimumHeap);
  Serial.printf("LARGEST FREE BLOCK     : %lu bytes\n", (unsigned long)largestBlock);

  if (WiFi.isConnected()) {
    Serial.printf("RSSI                   : %d dBm\n", WiFi.RSSI());
    Serial.print("IP ADDRESS             : "); Serial.println(WiFi.localIP());
  }
  Serial.println("================================================");
}

// ============================================================
// 18. EVENT HISTORY
// ============================================================

void printHistory() {
  Serial.println();
  Serial.println("========== LAST WIFI EVENTS ==========");
  for (uint8_t i = 0; i < historyCount; i++) {
    uint8_t index = (historyIndex + HISTORY_SIZE - historyCount + i) % HISTORY_SIZE;
    EventRecord event = history[index];
    const char* eventName = "UNKNOWN";

    switch (event.type) {
      case EVENT_INITIAL_CONNECT: eventName = "INITIAL CONNECT"; break;
      case EVENT_CONNECT_SUCCESS: eventName = "CONNECT SUCCESS"; break;
      case EVENT_CONNECT_FAILED: eventName = "CONNECT FAILED"; break;
      case EVENT_DISCONNECT: eventName = "DISCONNECT"; break;
      case EVENT_RANDOM_DISCONNECT: eventName = "RANDOM DISCONNECT"; break;
    }

    Serial.printf("[%lu ms] %-20s DURATION: %lu ms\n",
      (unsigned long)event.timestamp, eventName, (unsigned long)event.duration);
  }
  Serial.println("======================================");
}

// ============================================================
// 19. SERIAL COMMAND
// ============================================================

void serialManager() {
  while (Serial.available() > 0) {
    char command = Serial.read();
    if (command == 'h' || command == 'H') printHistory();
    if (command == 's' || command == 'S') printStatistics(millis());
  }
}

// ============================================================
// 20. SETUP
// ============================================================

void setup() {
  Serial.begin(115200);
  Serial.println(); Serial.println();
  Serial.println("==============================================");
  Serial.println(" NEOTECH ESP32 WIFI ENDURANCE TEST v2.2 FIXED");
  Serial.println("==============================================");
  Serial.printf("ULONG_MAX : %lu\n", (unsigned long)ULONG_MAX);
  Serial.printf("COUNTER MAX : %lu\n", (unsigned long)COUNTER_MAX);
  Serial.println("RANDOM DISCONNECT : 5 - 10 MINUTES");
  Serial.printf("CONNECT TIMEOUT   : %lu ms\n", (unsigned long)CONNECT_TIMEOUT);
  Serial.println("TIMER             : MILLIS()");
  Serial.println("DELAY             : OPTIMIZED POLLING");
  Serial.println("----------------------------------------------");

  randomSeed(esp_random());
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(false);
  WiFi.setSleep(false);
  WiFi.persistent(false);

  uint32_t now = millis();
  disconnectedSince = now;
  lastLogAt = now;
  updateMemoryStatistics();

  Serial.println("[SYSTEM] WIFI INITIALIZED");
  startConnection(now);
  Serial.println("[SYSTEM] ENDURANCE TEST STARTED");
  Serial.println("----------------------------------------------");
  Serial.println("SERIAL COMMANDS:");
  Serial.println("S = SHOW STATISTICS");
  Serial.println("H = SHOW LAST 20 EVENTS");
  Serial.println("==============================================");
}

// ============================================================
// 21. MAIN LOOP (SUPER OPTIMIZED)
// ============================================================

void loop() {
  uint32_t now = millis();

  // 1. Counter (Dijalankan secepat mungkin tanpa blocking)
  updateCounter();

  // 2. Polling WiFi Status (Hanya setiap 50ms agar loop TIDAK LAMBAT & Counter cepat naik)
  static uint32_t lastWifiPoll = 0;
  bool connectedNow = connectedLastLoop;
  
  if ((uint32_t)(now - lastWifiPoll) >= 50) {
    lastWifiPoll = now;
    connectedNow = (WiFi.status() == WL_CONNECTED);
    yield(); // Mencegah Watchdog Timer (WDT) Reset
  }

  if (connectedNow && !connectedLastLoop) {
    connectionSuccess(now);
  }

  if (!connectedNow && connectedLastLoop) {
    connectionLost(now);
  }

  connectedLastLoop = connectedNow;

  // 3. Random disconnect
  if (connectedNow) {
    randomDisconnectManager(now);
  }

  // 4. Automatic reconnect
  if (!connectedNow) {
    reconnectManager(now);
  }

  // 5. Memory monitoring
  updateMemoryStatistics();

  // 6. Statistics
  printStatistics(now);

  // 7. Serial command
  serialManager();
}